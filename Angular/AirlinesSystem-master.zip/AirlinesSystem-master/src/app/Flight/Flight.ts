import { Admin } from "../Admin/Admin";

export class Flight
{
    flightNumber : number = 0;
    flightName : string = "";
    origin : string = "";
    destination : string = "";
    departureDate : string = "";
    arrivalDate : string = "";
    returnDate : string = "";
    
    
}
