export class Seat
{
    seatNumber : String = "";
    flightNumber :String ="";
    seatType : String ="";
    seatCost : number = 0;
}