export class Passenger{
    passId :any;
    fName :string="";
    lName :string="";
    gender :string="";
    email :string="";
    password :string="";
    doB : string=""; 
    phoneNum: number=0;
}