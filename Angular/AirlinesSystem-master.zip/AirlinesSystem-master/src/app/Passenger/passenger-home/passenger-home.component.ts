import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passenger-home',
  templateUrl: './passenger-home.component.html',
  styleUrls: ['./passenger-home.component.css']
})
export class PassengerHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
