export class City
{
    cityId : number = 0;
    cityName : string = "";
}