import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-city-by-id',
  templateUrl: './search-city-by-id.component.html',
  styleUrls: ['./search-city-by-id.component.css']
})
export class SearchCityByIdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
