export class Admin
{
    adminId : number =0;
    loginId : string = "";
    password : string = "";
    adminName : string = "";
}